# Copyright 2022-2023 OmniSafe Team. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Hazard."""

from dataclasses import dataclass, field

import numpy as np
from safety_gymnasium.assets.color import COLOR
from safety_gymnasium.assets.group import GROUP
from safety_gymnasium.bases.base_object import Geom


#For STL Monitoring
import rtamt
# Adjust from string to rtamt-format spec (trace)
def specification(spec_str):
    spec = rtamt.StlDenseTimeSpecification()
    spec.name = 'STL dense-time online monitor'
    spec.declare_var('agent_x', 'float')
    spec.declare_var('agent_y', 'float')
    spec.spec = spec_str
    spec.parse()
    return spec

# Robustness of a trace
def robustness(dataset, spec):
    rob = spec.evaluate(['agent_x',dataset[0]],['agent_y',dataset[1]])
    #,['goal_x',dataset[2]], ['goal_y',dataset[3]], ['H1_x',dataset[4]], ['H1_y',dataset[5]], ['H2_x',dataset[6]], ['H2_y',dataset[7]]
    return [i[1] for i in rob]

def signal(states):
    x = []
    y = []
    for j in range(len(states)):       
        x.append([j,states[j][0]])
        y.append([j,states[j][1]])
    return (x, y)

# Robustness of a state
def specification_cs(spec_str):
    spec= rtamt.StlDiscreteTimeSpecification()
    spec.name = 'STL_goal'
    spec.declare_var('agent_x', 'float')
    spec.declare_var('agent_y', 'float')
    spec.spec = spec_str
    spec.parse()
    return spec
# Specification of a state
def robustness_cs(spec,current_state):  # Online Monitor
    rob = spec.update(0, [('agent_x', current_state[0]) , ('agent_y', current_state[1])])
    return rob

@dataclass
class Hazards(Geom):  # pylint: disable=too-many-instance-attributes
    """Hazardous areas."""

    name: str = 'hazards'
    num: int = 0  # Number of hazards in an environment
    size: float = 0.2
    placements: list = None  # Placements list for hazards (defaults to full extents)
    locations: list = field(default_factory=list)  # Fixed locations to override placements
    keepout: float = 0.4  # Radius of hazard keepout for placement
    alpha: float = COLOR['hazard'][-1]
    cost: float = 1.0  # Cost (per step) for violating the constraint

    color: np.array = COLOR['hazard']
    group: np.array = GROUP['hazard']
    is_lidar_observed: bool = True
    is_constrained: bool = True
    is_meshed: bool = False

    def get_config(self, xy_pos, rot):
        """To facilitate get specific config for this object."""
        geom = {
            'name': self.name,
            'size': [self.size, 1e-2],  # self.hazards_size / 2],
            'pos': np.r_[xy_pos, 2e-2],  # self.hazards_size / 2 + 1e-2],
            'rot': rot,
            'type': 'cylinder',
            'contype': 0,
            'conaffinity': 0,
            'group': self.group,
            'rgba': self.color,
        }
        if self.is_meshed:
            geom.update(
                {
                    'type': 'mesh',
                    'mesh': 'bush',
                    'material': 'bush',
                    'euler': [np.pi / 2, 0, 0],
                },
            )
        return geom
    # def cal_cost(self):
    #         """Contacts Processing."""
    #         cost = {}
    #         if not self.is_constrained:
    #             return cost
    #         cost['cost_hazards'] = 0
    #         for h_pos in self.pos:
    #             h_dist = self.agent.dist_xy(h_pos)
    #             # pylint: disable=no-member
    #             if h_dist <= self.size:
    #                 cost['cost_hazards'] += self.cost * (self.size - h_dist)
    
    #         return cost

    def cal_cost(self,spec_obs):
        """Contacts Processing."""
        # print('Hazards are at: ',self.pos)        
        # ***************** 
        current_state = (self.agent.pos[0], self.agent.pos[1])        #get current agent position
        # print('current_state:',current_state)
        rob_obs = robustness_cs(specification_cs(spec_obs), current_state )     #Compute robustness of the current state for the cost STL  
        # print('**********',agent_pos , rob_goal, rob_obs)
        
        # print(rob_obs)

        # cost_stl = rob_obs > 0
        cost_stl = rob_obs
        # ***************** 
        
        cost = {}
        if not self.is_constrained:
            return cost
        cost['cost_hazards'] = 0
        if cost_stl > 0:
            cost['cost_hazards'] += cost_stl
        
        # print('STL cost: ',cost['cost_hazards'] )
        # ***************** 
        return cost

    @property
    def pos(self):
        """Helper to get the hazards positions from layout."""
        # pylint: disable-next=no-member
        return [self.engine.data.body(f'hazard{i}').xpos.copy() for i in range(self.num)]
