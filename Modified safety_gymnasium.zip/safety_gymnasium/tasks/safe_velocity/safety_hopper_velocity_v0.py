# Copyright 2022-2023 OmniSafe Team. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Hopper environment with a safety constraint on velocity."""

from gymnasium.envs.mujoco.hopper_v4 import HopperEnv

from safety_gymnasium.utils.task_utils import add_velocity_marker, clear_viewer

#For STL Monitoring
import rtamt
# Adjust from string to rtamt-format spec (trace)
def specification(spec_str):
    spec = rtamt.StlDenseTimeSpecification()
    spec.name = 'STL dense-time online monitor'
    spec.declare_var('vx_threshold', 'float')
    spec.spec = spec_str
    spec.parse()
    return spec

# Robustness of a trace
def robustness(dataset, spec):
    rob = spec.evaluate(['vx_threshold',dataset[0]])
    #,['goal_x',dataset[2]], ['goal_y',dataset[3]], ['H1_x',dataset[4]], ['H1_y',dataset[5]], ['H2_x',dataset[6]], ['H2_y',dataset[7]]
    return [i[1] for i in rob]

def signal(states):
    x = []
    y = []
    for j in range(len(states)):       
        x.append([j,states[j][0]])
        y.append([j,states[j][1]])
    return (x, y)

# Robustness of a state
def specification_cs(spec_str):
    spec= rtamt.StlDiscreteTimeSpecification()
    spec.name = 'STL_obs'
    spec.declare_var('v_x', 'float')
    spec.spec = spec_str
    spec.parse()
    return spec
# Specification of a state
def robustness_cs(spec,v_x):  # Online Monitor
    rob = spec.update(0, [('v_x', v_x)])
    return rob

class SafetyHopperVelocityEnv(HopperEnv):
    """Hopper environment with a safety constraint on velocity."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._velocity_threshold = 0.37315
        self.model.light(0).castshadow = False
        self.states = []
        self.st = []

    def step(self, action):
        x_position_before = self.data.qpos[0]
        self.do_simulation(action, self.frame_skip)
        x_position_after = self.data.qpos[0]
        x_velocity = (x_position_after - x_position_before) / self.dt

        ctrl_cost = self.control_cost(action)

        forward_reward = self._forward_reward_weight * x_velocity
        healthy_reward = self.healthy_reward

        rewards = forward_reward + healthy_reward
        costs = ctrl_cost

        observation = self._get_obs()
        reward = rewards - costs
        terminated = self.terminated
        info = {
            'x_position': x_position_after,
            'x_velocity': x_velocity,
        }
        
        self.st.append((x_position_after,x_velocity))

        if terminated:
            self.states.append(self.st)
            self.st = []
            info['states'] = self.states

        # cost = float(x_velocity > self._velocity_threshold)
        
        
        # ***************** 
        rob_obs = robustness_cs(specification_cs(self._spec_obs), x_velocity )     #Compute robustness of the current state for the cost STL  
        cost_stl = float(rob_obs > 0)
        
        
        
        # print('**********',rob_obs, self._spec_obs, cost, cost_stl)

        cost = cost_stl
        # ***************** 

        if self.mujoco_renderer.viewer:
            clear_viewer(self.mujoco_renderer.viewer)
            add_velocity_marker(
                viewer=self.mujoco_renderer.viewer,
                pos=self.get_body_com('torso')[:3].copy(),
                vel=x_velocity,
                cost=cost,
                velocity_threshold=self._velocity_threshold,
            )
        if self.render_mode == 'human':
            self.render()
        return observation, reward, cost, terminated, False, info
